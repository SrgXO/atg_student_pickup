"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function ParentBottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 border-t bg-white">
      <div className="mx-auto flex max-w-md justify-around">

        <Link href="/parent">
          Home
        </Link>

        <Link href="/parent/pickup">
          Pickup
        </Link>

        <Link href="/parent/status">
          Status
        </Link>

        <Link href="/parent/profile">
          Profile
        </Link>

      </div>
    </nav>
  );
}