"use client";

import Link from "next/link";

export default function TeacherBottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 border-t bg-white">
      <div className="mx-auto flex max-w-md justify-around p-4">

        <Link href="/teacher">
          Queue
        </Link>

        <Link href="/teacher/history">
          History
        </Link>

        <Link href="/teacher/profile">
          Profile
        </Link>

      </div>
    </nav>
  );
}