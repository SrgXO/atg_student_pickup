import Link from "next/link";
import { students } from "@/data/students";

export default function ParentPage() {
return (
    <main className="min-h-screen bg-white">
      <div className="mx-auto max-w-md">
        <header className="border-b border-gray-100 px-4 pb-5 pt-10">
          <p className="text-xs uppercase tracking-widest text-gray-400">
            Good afternoon
          </p>

          <div className="mt-1 flex items-center justify-between">
            <div>
              <h1 className="text-lg font-bold text-black">
                Sarah Miller 
              </h1>

              <p className="mt-1 text-xs text-gray-400">
                Tue, 30 Jun 2026
              </p>
            </div>

            <span className="rounded-full bg-black px-3 py-1 text-xs font-semibold text-white">
              Parent
            </span>
          </div>
        </header>

        <section className="px-4 pt-24">
          <Link
            href="/parent/pickup"
            className="block w-full rounded-xl bg-black px-6 py-7 text-center text-xl font-semibold text-white transition hover:bg-gray-800"
          >
            Create a Pickup Request
          </Link>
        </section>

        <section className="px-4 pt-28">
          <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-gray-400">
            My Child
          </p>

          <div className="space-y-3">
            {students.map((student) => (
              <div
                key={student.id}
                className="flex items-center gap-4 rounded-xl border border-gray-200 p-4"
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-gray-300 bg-gray-100 text-sm font-semibold text-gray-600">
                  {student.initials}
                </div>

                <div>
                  <h2 className="text-sm font-semibold text-black">
                    {student.name}
                  </h2>

                  <p className="text-xs text-gray-400">
                    {student.className}
                  </p>

                  <p className="text-xs text-gray-300">
                    {student.studentNo}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        
      </div>
    </main>
  );
}