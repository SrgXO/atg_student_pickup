"use client";

import { useSearchParams } from "next/navigation";

import {
  Clock3,
  MapPin,
} from "lucide-react";

import { students } from "@/data/students";


export default function ParentStatusPage() {

  const searchParams = useSearchParams();

  const studentId =
    Number(searchParams.get("student")) || 1;

  const queue =
    searchParams.get("queue") || "A-011";


  const student =
    students.find(
      (item) => item.id === studentId
    ) || students[0];


  const status = "Preparing";


  return (

    <main className="min-h-screen bg-white">

      <div className="mx-auto max-w-md pb-10">


        {/* HEADER */}

        <header className="border-b border-gray-100 px-4 pb-5 pt-9">

          <p className="text-[10px] uppercase tracking-widest text-gray-400">
            Good Afternoon
          </p>

          <div className="mt-1 flex justify-between">

            <div>

              <h1 className="text-sm font-bold">
                Mdm. Lim Siew Chin
              </h1>

              <p className="mt-1 text-xs text-gray-400">
                Tue, 30 Jun 2026
              </p>

            </div>

            <span className="h-fit rounded-full bg-black px-3 py-1 text-[10px] font-semibold text-white">
              Parent
            </span>

          </div>

        </header>


        <section className="px-4 pt-8">

          <div className="flex items-center justify-between">

            <h2 className="text-xs font-bold uppercase tracking-[0.15em] text-green-600">
              Pickup Queue Status
            </h2>

            <Clock3
              size={16}
              className="text-gray-400"
            />

          </div>


          {/* ACTIVE PICKUP */}

          <div className="mt-5 rounded-xl bg-black p-5 text-white">

            <div className="flex justify-between">

              <div>

                <p className="text-[9px] uppercase tracking-widest text-gray-500">
                  Active Pickup
                </p>

                <h3 className="mt-2 text-sm font-semibold">
                  {student.name}
                </h3>

                <p className="text-xs text-gray-400">
                  {student.className}
                </p>

              </div>


              <div className="text-right">

                <p className="text-[9px] uppercase tracking-widest text-gray-500">
                  Queue No.
                </p>

                <p className="mt-1 text-3xl font-bold">
                  {queue}
                </p>

              </div>

            </div>


            {/* STATUS */}

            <div className="mt-5 flex items-center justify-between border-t border-gray-700 pt-4">

              <span className="rounded-full bg-yellow-300 px-3 py-1 text-[10px] font-bold text-black">
                {status}
              </span>


              <div className="flex items-center gap-1 text-[10px] text-gray-400">

                <MapPin size={12} />

                Main Gate

              </div>

            </div>

          </div>

        </section>

      </div>

    </main>
  );
}