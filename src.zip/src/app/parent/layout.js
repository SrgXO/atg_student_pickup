import BottomNav from "@/components/BottomNav";

export default function ParentLayout({
  children,
}) {
  return (
    <>
      <div className="pb-20">
        {children}
      </div>

      <BottomNav />
    </>
  );
}