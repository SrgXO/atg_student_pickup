"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  MapPin,
  Info,
  CheckCircle2,
} from "lucide-react";

import { students } from "@/data/students";

export default function PickupPage() {
  const router = useRouter();

  const [selectedStudents, setSelectedStudents] = useState([1]);

  const [gate, setGate] = useState(
    "Building A — Main Gate"
  );

  function handleConfirmArrival() {
    
    const queueNumber = "A-011";

    router.push(
      `/parent/pickup/confirmation?students=${selectedStudents.join(",")}&queue=${queueNumber}`
      
    );
    
  }

  return (
    <main className="min-h-screen bg-white">
      <div className="mx-auto max-w-md px-4 pb-10 pt-8">

        {/* PAGE TITLE */}

        <div className="rounded-xl bg-neutral-950 px-5 py-7 text-center">
          <h1 className="text-xl font-semibold text-white">
            Create a Pickup Request
          </h1>
        </div>


        {/* PROGRESS */}

        <div className="mt-12 rounded-xl border border-gray-200 p-4">

          <div className="flex items-center">

            <div className="flex items-center gap-2">

              <div className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-black text-xs font-bold">
                1
              </div>

              <span className="text-xs font-semibold">
                Confirm Arrival
              </span>

            </div>


            <div className="mx-3 h-px flex-1 bg-gray-200" />


            <div className="flex items-center gap-2 text-gray-300">

              <div className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-gray-200 text-xs font-bold">
                2
              </div>

              <span className="text-xs">
                Queue Assigned
              </span>

            </div>

          </div>

        </div>


        {/* CHILD SELECT */}

        <section className="mt-5">

          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.15em] text-gray-400">
            Select Child
          </p>

          <div className="space-y-3">

            {students.map((student) => {

              const selected =
                selectedStudents.includes(student.id);

              return (

                <button
                  key={student.id}
                  type="button"
                  onClick={() =>
                    setSelectedStudents((current) => {
                      if (current.includes(student.id)) {
                        return current.filter((id) => id !== student.id);
                      } else {
                        return [...current, student.id];
                      }
                    })
                  }
                  className={`flex w-full items-center gap-3 rounded-xl border p-4 text-left transition ${
                    selected
                      ? "border-black"
                      : "border-gray-200"
                  }`}
                >

                  {/* RADIO */}

                  <div
                    className={`flex h-5 w-5 items-center justify-center rounded-full border-2 ${
                      selected
                        ? "border-black"
                        : "border-gray-400"
                    }`}
                  >
                    {selected && (
                      <div className="h-2 w-2 rounded-full bg-black" />
                    )}
                  </div>


                  {/* INITIALS */}

                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-gray-300 bg-gray-100 text-xs font-semibold text-gray-600">
                    {student.initials}
                  </div>


                  {/* STUDENT */}

                  <div>

                    <p className="text-sm font-semibold">
                      {student.name}
                    </p>

                    <p className="text-xs text-gray-400">
                      {student.className}
                    </p>

                  </div>

                </button>
              );

            })}

          </div>

        </section>


        {/* GATE */}

        <section className="mt-10">

          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.15em] text-gray-400">
            Gate Location
          </p>

          <div className="flex items-center gap-3 rounded-xl border border-gray-200 px-4">

            <MapPin
              size={18}
              className="text-gray-400"
            />

            <select
              value={gate}
              onChange={(event) =>
                setGate(event.target.value)
              }
              className="w-full bg-white py-4 text-sm outline-none"
            >
              <option>
                Building A — Main Gate
              </option>

              <option>
                Building B — East Gate
              </option>

            </select>

          </div>

        </section>


        {/* WARNING */}

        <div className="mt-4 rounded-xl border border-gray-200 p-4">

          <div className="flex gap-3">

            <Info
              size={18}
              className="shrink-0 text-gray-400"
            />

            <div>

              <p className="text-xs font-semibold">
                Before you proceed
              </p>

              <p className="mt-1 text-xs leading-5 text-gray-400">
                Confirm you are physically at the gate.
                Keep your phone accessible. Do not enter
                school premises.
              </p>

            </div>

          </div>

        </div>


        {/* ACTIONS */}

        <div className="mt-5 flex gap-3">

          <Link
            href="/parent"
            className="flex items-center justify-center rounded-xl bg-gray-100 px-5 py-4 text-sm font-semibold"
          >
            Cancel
          </Link>


          <button
            type="button"
            onClick={handleConfirmArrival}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-black px-4 py-4 text-sm font-semibold text-white"
          >
            <CheckCircle2 size={17} />

            Confirm Arrival
          </button>

        </div>

      </div>
    </main>
  );
}