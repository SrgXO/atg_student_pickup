"use client";

import { useRouter } from "next/navigation";
import { currentUser } from "@/data/users";

export default function ParentProfile() {
  const router = useRouter();

  const canSwitchToTeacher =
    currentUser.role.includes("Parent") &&
    currentUser.role.includes("Teacher");

  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold">
        Profile
      </h1>

      <div className="mt-6">
        <h2 className="font-semibold">
          {currentUser.name}
        </h2>

        <p className="text-sm text-gray-500">
          Currently using Parent mode
        </p>
      </div>

      {canSwitchToTeacher && (
        <div className="mt-8 border-t pt-6">
          <p className="text-sm font-semibold">
            ROLE
          </p>

          <div className="mt-4">
            <p>Parent ✓</p>
            <p>Teacher</p>
          </div>

          <button
            onClick={() => router.push("/teacher")}
            className="mt-5 w-full rounded-xl bg-black p-3 text-white"
          >
            Switch to Teacher Mode
          </button>

          <p className="mt-3 text-sm text-gray-500">
            {currentUser.onDuty
              ? "Teacher • On Duty Today"
              : "Teacher • Off Duty Today"}
          </p>
        </div>
      )}
    </main>
  );
}