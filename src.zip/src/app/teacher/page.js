"use client";

import { useState } from "react";
import {
  ClipboardList,
  Clock3,
  CircleCheck,
  CheckCheck,
  MapPin,
} from "lucide-react";

import {pickups} from "@/data/pickups";
import Link from "next/link";
import { currentUser } from "@/data/users";


{currentUser.role.includes("Parent") && (
  <Link href="/parent">
    Switch to Parent
  </Link>
)}


export default function TeacherPage() {
  const [requests, setRequests] = useState(pickups);
  const [activeTab, setActiveTab] = useState("NEW");

  function updateStatus(id, newStatus) {
    setRequests((currentRequests) =>
      currentRequests.map((request) =>
        request.id === id
          ? { ...request, status: newStatus }
          : request
      )
    );
  }

  function countStatus(status) {
    return requests.filter(
      (request) => request.status === status
    ).length;
  }

  const filteredRequests = requests.filter(
    (request) => request.status === activeTab
  );

  return (
    <main className="min-h-screen bg-white">
      <div className="mx-auto max-w-md pb-10">

        <header className="border-b border-gray-100 px-4 pb-5 pt-10">
          <p className="text-xs uppercase tracking-widest text-gray-400">
            Teacher on Duty
          </p>

          <div className="mt-1 flex items-start justify-between">
            <div>
              <h1 className="text-lg font-bold">
                Emily Carter
              </h1>

              <p className="mt-1 text-xs text-gray-400">
                KG-1A · Building A
              </p>
            </div>

            <span className="rounded-full bg-black px-3 py-1 text-[10px] font-semibold text-white">
              On Duty
            </span>
          </div>
        </header>

        <section className="px-4 pt-6">
          <div className="grid grid-cols-2 gap-3">

            <StatusTab
              title="New"
              count={countStatus("NEW")}
              status="NEW"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              icon={<ClipboardList size={18} />}
            />

            <StatusTab
              title="Preparing"
              count={countStatus("PREPARING")}
              status="PREPARING"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              icon={<Clock3 size={18} />}
            />

            <StatusTab
              title="Ready"
              count={countStatus("READY")}
              status="READY"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              icon={<CircleCheck size={18} />}
            />

            <StatusTab
              title="Completed"
              count={countStatus("COMPLETED")}
              status="COMPLETED"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              icon={<CheckCheck size={18} />}
            />

          </div>
        </section>

        <section className="px-4 pt-7">

          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-gray-400">
                {getTabTitle(activeTab)}
              </p>

              <p className="mt-1 text-xs text-gray-400">
                {filteredRequests.length} request
                {filteredRequests.length !== 1 ? "s" : ""}
              </p>
            </div>

            <button
              type="button"
              className="rounded-lg border border-gray-200 px-3 py-2 text-xs"
            >
              ↻
            </button>
          </div>

          <div className="space-y-4">
            {filteredRequests.length === 0 && (
              <div className="rounded-xl border border-gray-200 p-8 text-center">
                <p className="text-sm text-gray-400">
                  No requests in this section.
                </p>
              </div>
            )}

            {filteredRequests.map((request) => (
              <div
                key={request.id}
                className="rounded-xl border border-gray-200 p-4"
              >
                <div className="flex items-start justify-between gap-4">

                  <div>
                    <p className="text-2xl font-bold">
                      {request.queueNumber}
                    </p>

                    <p className="mt-2 text-sm font-semibold">
                      {request.studentNames.join(", ")}
                    </p>

                    <p className="text-xs text-gray-400">
                      {request.classrooms.join(", ")}
                    </p>
                  </div>

                  <StatusBadge status={request.status} />

                </div>

                <div className="mt-5 flex items-center justify-between text-xs text-gray-400">
                  <span>
                    {request.arrivalTime}
                  </span>

                  <span className="flex items-center gap-1">
                    <MapPin size={12} />
                    Main Gate
                  </span>
                </div>

                <ActionButton
                  request={request}
                  updateStatus={updateStatus}
                  canManage = {currentUser.onDuty}
                />
              </div>
            ))}
          </div>
        </section>

      </div>
    </main>
  );
}

function StatusTab({
  title,
  count,
  status,
  activeTab,
  setActiveTab,
  icon,
}) {
  const active = activeTab === status;

  return (
    <button
      type="button"
      onClick={() => setActiveTab(status)}
      className={`rounded-xl border p-4 text-left ${
        active
          ? "border-black bg-black text-white"
          : "border-gray-200 bg-white text-black"
      }`}
    >
      <div className="flex items-start justify-between">
        <span
          className={`text-[10px] font-semibold uppercase tracking-widest ${
            active ? "text-gray-300" : "text-gray-400"
          }`}
        >
          {title}
        </span>

        <span
          className={active ? "text-white" : "text-gray-400"}
        >
          {icon}
        </span>
      </div>

      <p className="mt-3 text-3xl font-bold">
        {count}
      </p>
    </button>
  );
}

function ActionButton({
  request,
  updateStatus,
  canManage,
}) {
  let label;
  let nextStatus;
  if (!canManage){
    return (
      <div> Off duty - view only</div>
    );
  }
  if (request.status === "NEW") {
    label = "Accept Pickup Request";
    nextStatus = "PREPARING";
  }

  if (request.status === "PREPARING") {
    label = "Mark Ready";
    nextStatus = "READY";
  }

  if (request.status === "READY") {
    label = "Pickup Successful";
    nextStatus = "COMPLETED";
  }

  if (request.status === "COMPLETED") {
    return (
      <div className="mt-4 rounded-lg bg-gray-100 py-3 text-center text-sm font-semibold text-gray-500">
        Completed
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={() =>
        updateStatus(request.id, nextStatus)
      }
      className="mt-4 w-full rounded-lg bg-black py-3 text-sm font-semibold text-white"
    >
      {label}
    </button>
  );
}

function StatusBadge({ status }) {
  const labels = {
    NEW: "New",
    PREPARING: "Preparing",
    READY: "Ready",
    COMPLETED: "Picked Up",
  };

  let style = "bg-gray-100 text-gray-700";

  if (status === "NEW") {
    style = "bg-blue-50 text-blue-700";
  }

  if (status === "PREPARING") {
    style = "bg-yellow-50 text-yellow-700";
  }

  if (status === "READY") {
    style = "bg-green-50 text-green-700";
  }

  if (status === "COMPLETED") {
    style = "bg-gray-800 text-white";
  }

  return (
    <span
      className={`rounded-full px-3 py-1 text-[10px] font-semibold ${style}`}
    >
      {labels[status]}
    </span>
  );
}

function getTabTitle(status) {
  if (status === "NEW") {
    return "New Requests";
  }

  if (status === "PREPARING") {
    return "Preparing";
  }

  if (status === "READY") {
    return "Ready for Pickup";
  }

  return "Completed";
}