import TeacherBottomNav from "@/components/TeacherBottomNav";

export default function TeacherLayout({ children }) {
  return (
    <>
      <div className="pb-20">
        {children}
      </div>

      <TeacherBottomNav />
    </>
  );
}