"use client";

import { useRouter } from "next/navigation";
import { currentUser } from "@/data/users";

export default function TeacherProfile() {
  const router = useRouter();

  const canSwitchToParent =
    currentUser.role.includes("Teacher") &&
    currentUser.role.includes("Parent");

  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold">Profile</h1>

      {/* Teacher information */}
      <div className="mt-6">
        <h2 className="text-lg font-semibold">
          {currentUser.name}
        </h2>

        <p className="text-sm text-gray-500">
          Teacher
        </p>

        <p className="mt-2 text-sm">
          {currentUser.onDuty
            ? "On Duty Today"
            : "Off Duty Today"}
        </p>
      </div>

      {/* Role Switch */}
      {canSwitchToParent && (
        <div className="mt-8 border-t pt-6">
          <p className="text-sm font-semibold">
            ROLE
          </p>

          <div className="mt-4 space-y-2">
            <p>Teacher ✓</p>
            <p>Parent</p>
          </div>

          <button
            onClick={() => router.push("/parent")}
            className="mt-5 w-full rounded-xl bg-black p-3 text-white"
          >
            Switch to Parent Mode
          </button>
        </div>
      )}
    </main>
  );
}