import Link from "next/link";

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-white px-6 py-10">
      <div className="mx-auto flex min-h-[800px] max-w-md flex-col justify-center">

        <div className="mb-12 text-center">
          <img
            src="/ATG_logo.png"
            alt="ATG Logo"
            className="mx-auto mb-4 w-32"
          />
          <h1 className="text-lg font-bold">
            Student Pickup Management System
          </h1>

          <p className="mt-2 text-sm text-gray-400">
            Sign in to continue
          </p>
        </div>

        <div className="rounded-3xl border border-gray-200 p-6">

          <div className="mb-5">
            <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-gray-600">
              Email Address
            </label>

            <input
              type="email"
              placeholder="you@atg.edu.my"
              className="w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-4 text-sm outline-none focus:border-black"
            />
          </div>

          <div className="mb-4">
            <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-gray-600">
              Password
            </label>

            <input
              type="password"
              placeholder="••••••••"
              className="w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-4 text-sm outline-none focus:border-black"
            />
          </div>

          <div className="mb-5 flex items-center justify-between text-xs text-gray-500">
            <label className="flex items-center gap-2">
              <input type="checkbox" />
              Remember me
            </label>

            <button type="button" className="underline">
              Forgot password?
            </button>
          </div>

          <Link
            href="/parent"
          >
            <button
              type = 'button'
              className="w-full rounded-xl bg-black py-4 font-semibold text-white"
            >
              Sign in
            </button>
          </Link>
        </div>

        <div className="mt-10 text-center text-xs text-gray-400">
          <p>
            Need an account?{" "}
            <span className="text-gray-600 underline">
              Contact school admin
            </span>
          </p>

          <p className="mt-4">
            ATG Student Pickup System v1.0
          </p>
        </div>
      </div>
    </main>
  );
}