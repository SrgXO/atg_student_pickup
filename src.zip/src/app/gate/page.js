"use client";

import { useEffect, useState } from "react";
import {
  Clock3,
  Users,
  CheckCircle2,
  RotateCw,
  School,
  Circle,
} from "lucide-react";

import {pickups} from "@/data/pickups";


export default function GatePage() {
  const [queue] = useState(pickups);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);


  const preparing = queue.filter(
    (item) => item.status === "PREPARING"
  );

  const ready = queue.filter(
    (item) => item.status === "READY"
  );

  const pickedUp = queue.filter(
    (item) => item.status === "PICKED_UP"
  );

  return (
    <main className="min-h-screen bg-[#eeeeee] text-black">
      <div className="flex min-h-screen flex-col">

        {/* ================= HEADER ================= */}

        <header className="flex items-center justify-between bg-white px-8 py-5">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gray-100">
              <School size={22} />
            </div>

            <div>
              <h1 className="text-xl font-black tracking-tight">
                ATG STUDENT PICKUP MANAGEMENT SYSTEM
              </h1>

              <p className="mt-1 text-xs text-gray-400">
                Building A — Main Gate · Gate Display
              </p>
            </div>
          </div>

          <div className="text-right">
            <p className="font-mono text-xl font-bold">
              {currentTime.toLocaleTimeString()}
            </p>

            <p className="mt-1 text-xs text-gray-400">
              {currentTime.toLocaleDateString("en-US", {
                weekday: "short",
                day: "numeric",
                month: "short",
                year: "numeric",
              })}
            </p>
          </div>
        </header>

        {/* ================= BLACK STATUS BAR ================= */}

        <section className="flex items-center justify-between bg-[#111111] px-8 py-3 text-white">
          <div className="flex items-center gap-10">
            <Summary
              label="Preparing"
              value={preparing.length}
            />

            <Summary
              label="Ready for Pickup"
              value={ready.length}
            />

            <Summary
              label="Picked Up Today"
              value={pickedUp.length}
            />

            <Summary
              label="Total Queue"
              value={queue.length}
            />
          </div>

          <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-wider text-gray-400">
            <Circle
              size={7}
              fill="currentColor"
            />

            Live · Refreshes every 10s
          </div>
        </section>

        {/* ================= THREE COLUMNS ================= */}

        <section className="grid flex-1 grid-cols-3 divide-x divide-gray-300">

          {/* PREPARING */}

          <QueueColumn
            title="Preparing"
            subtitle="Teacher is fetching your child"
            count={preparing.length}
            icon={<RotateCw size={18} />}
          >
            {preparing.map((item) => (
              <PreparingCard
                key={item.id}
                pickup={item}
              />
            ))}
          </QueueColumn>

          {/* READY */}

          <QueueColumn
            title="Ready for Pickup"
            subtitle="Please proceed to the gate now"
            count={ready.length}
            icon={<Users size={18} />}
          >
            {ready.map((item) => (
              <ReadyCard
                key={item.id}
                pickup={item}
              />
            ))}
          </QueueColumn>

          {/* PICKED UP */}

          <QueueColumn
            title="Picked Up"
            subtitle="Successfully collected today"
            count={pickedUp.length}
            icon={<CheckCircle2 size={18} />}
          >
            {pickedUp.map((item) => (
              <PickedUpCard
                key={item.id}
                pickup={item}
              />
            ))}
          </QueueColumn>

        </section>

        {/* ================= FOOTER ================= */}

        <footer className="flex items-center justify-between border-t border-gray-200 bg-white px-8 py-3 text-[10px] text-gray-400">
          <p>
            Thank you for your patience. This display refreshes
            automatically every 10 seconds.
          </p>

          <p>
            ATG Gate Display
          </p>
        </footer>

      </div>
    </main>
  );
}

/* =========================================================
COLUMN
========================================================= */

function QueueColumn({
  title,
  subtitle,
  count,
  icon,
  children,
}) {
  return (
    <div className="flex flex-col bg-[#f3f3f3]">
      <div className="flex items-start justify-between border-b border-gray-300 px-5 py-4">
        <div>
          <div className="flex items-center gap-2">
            {icon}

            <h2 className="text-sm font-black uppercase tracking-wide">
              {title}
            </h2>
          </div>

          <p className="mt-1 text-[10px] text-gray-400">
            {subtitle}
          </p>
        </div>

        <p className="text-lg font-bold">
          {count}
        </p>
      </div>

      <div className="space-y-3 p-4">
        {children}
      </div>
    </div>
  );
}

/* =========================================================
PREPARING CARD
========================================================= */

function PreparingCard({ pickup }) {
  return (
    <div className="rounded-md border border-gray-200 bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="font-mono text-xl font-black">
            {pickup.queueNumber}
          </p>
        </div>



          <p className="mt-1 text-[9px] text-gray-400">
            {pickup.time}
          </p>
        </div>
      </div>

  );
}

/* =========================================================
READY CARD
========================================================= */

function ReadyCard({ pickup }) {
  return (
    <div className="rounded-md bg-[#111111] p-4 text-white shadow-sm">
      <div className="flex items-center justify-between">
        <p className="font-mono text-2xl font-black">
          {pickup.queueNumber}
        </p>

        <div className="flex items-center gap-2 text-[10px] font-semibold">
          <Circle
            size={7}
            fill="currentColor"
          />

          Ready
        </div>
      </div>

    

      

        <p className="text-[9px] text-gray-400">
          Arrived {pickup.time}
        </p>
      </div>
  );
}

/* =========================================================
   PICKED UP CARD
========================================================= */

function PickedUpCard({ pickup }) {
  return (
    <div className="rounded-md border border-gray-200 bg-white p-4 opacity-55">
      <div className="flex items-center justify-between">
        <p className="font-mono text-xl font-black line-through">
          {pickup.queueNumber}
        </p>

        <span className="rounded bg-gray-600 px-2 py-1 text-[8px] font-semibold text-white">
          ✓ Picked Up
        </span>
      </div>

        <p className="text-[9px] text-gray-400">
          {pickup.time}
        </p>
      </div>
      
    
  );
}

/* =========================================================
   TOP SUMMARY
========================================================= */

function Summary({ label, value }) {
  return (
    <div className="flex items-center gap-2">
      <p className="text-[9px] font-semibold uppercase tracking-widest text-gray-500">
        {label}
      </p>

      <p className="text-lg font-bold">
        {value}
      </p>
    </div>
  );
}