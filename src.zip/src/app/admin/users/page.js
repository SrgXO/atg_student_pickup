"use client";

import { useState } from "react";

const users = [
  {
    id: 1,
    name: "Sarah Miller",
    role: ["Parent", "Teacher"],
    related: "Emma Miller",
    onDuty: true,
    status: "Active",
  },
  {
    id: 2,
    name: "Emily Carter",
    role: ["Teacher"],
    related: "KG-1A",
    onDuty: false,
    status: "Active",
  },
  {
  id: 3,
  name: "Emily Carter",
  roles: ["Teacher"],
  onDuty: true
},
{
    id: 4,
    name: "Emma Miller",
    role: ["Student"],
    related: "KG-1A",
    status: "Active",
  }
];

export default function UsersPage() {
  const [filter, setFilter] = useState("ALL");

  const filtered =
    filter === "ALL"
      ? users
      : users.filter(
          (user) =>
            user.role.includes(filter)
        );

  return (
    <main className="min-h-screen bg-gray-50 p-8">

      <h1 className="text-2xl font-bold">
        User Management
      </h1>

      <p className="mt-1 text-sm text-gray-400">
        Manage parents, teachers, and students
      </p>



      <div className="mt-8 flex gap-2">
        {["ALL", "PARENT", "TEACHER", "STUDENT"].map(
          (item) => (
            <button
              key={item}
              onClick={() => setFilter(item)}
              className={`rounded-lg px-4 py-2 text-sm ${
                filter === item
                  ? "bg-black text-white"
                  : "border border-gray-200 bg-white"
              }`}
            >
              {item}
            </button>
          )
        )}
      </div>

      <div className="mt-5 rounded-xl border border-gray-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-400">
            <tr>
              <th className="px-6 py-4">Name</th>
              <th className="px-6 py-4">Role</th>
              <th className="px-6 py-4">Related</th>
              <th className="px-6 py-4">Status</th>
            </tr>
          </thead>

          <tbody>
            {filtered.map((user) => (
              <tr
                key={user.id}
                className="border-t border-gray-100"
              >
                <td className="px-6 py-5 font-semibold">
                  {user.name}
                </td>

                <td className="px-6 py-5">
                  {user.role}
                </td>

                <td className="px-6 py-5 text-gray-500">
                  {user.related}
                </td>

                <td className="px-6 py-5">
                  <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                    {user.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

    </main>
  );
}