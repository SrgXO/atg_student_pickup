"use client";

const dutyRows = [
  {
    teacher: "Emily Carter",
    classroom: "KG-1A",
    gate: "Building A",
    date: "29 Aug 2026",
    time: "1:30 PM – 3:30 PM",
    status: "ON DUTY",
  },
  {
    teacher: "Daniel Brooks",
    classroom: "KG-1B",
    gate: "Building A",
    date: "29 Aug 2026",
    time: "1:30 PM – 3:30 PM",
    status: "ON DUTY",
  },
  {
    teacher: "Rachel Green",
    classroom: "KG-2A",
    gate: "Building B",
    date: "29 Aug 2026",
    time: "1:30 PM – 3:30 PM",
    status: "ON DUTY",
  },
];

export default function DutyPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="flex min-h-screen">

      

        <section className="flex-1">
          <header className="border-b border-gray-200 bg-white px-8 py-5">
            <h1 className="text-2xl font-bold">
              Duty Schedule
            </h1>

            <p className="mt-1 text-sm text-gray-400">
              Manage teacher dismissal assignments
            </p>
          </header>

          <div className="p-8">
            <div className="rounded-xl border border-gray-200 bg-white">

              <div className="flex items-center justify-between border-b border-gray-200 px-6 py-5">
                <div>
                  <h2 className="font-semibold">
                    Today&apos;s Assignments
                  </h2>

                  <p className="mt-1 text-xs text-gray-400">
                    29 August 2026
                  </p>
                </div>

                <button className="rounded-lg bg-black px-4 py-2 text-sm font-semibold text-white">
                  + Add Assignment
                </button>
              </div>

              <table className="w-full text-left text-sm">
                <thead className="bg-gray-50 text-xs uppercase text-gray-400">
                  <tr>
                    <th className="px-6 py-4">Teacher</th>
                    <th className="px-6 py-4">Classroom</th>
                    <th className="px-6 py-4">Gate</th>
                    <th className="px-6 py-4">Time</th>
                    <th className="px-6 py-4">Status</th>
                  </tr>
                </thead>

                <tbody>
                  {dutyRows.map((row) => (
                    <tr
                      key={row.teacher}
                      className="border-t border-gray-100"
                    >
                      <td className="px-6 py-5 font-semibold">
                        {row.teacher}
                      </td>

                      <td className="px-6 py-5">
                        {row.classroom}
                      </td>

                      <td className="px-6 py-5">
                        {row.gate}
                      </td>

                      <td className="px-6 py-5 text-gray-500">
                        {row.time}
                      </td>

                      <td className="px-6 py-5">
                        <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                          On Duty
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

            </div>
          </div>
        </section>

      </div>
    </main>
  );
}

