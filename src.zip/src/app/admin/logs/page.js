"use client";

const logs = [
  {
    queue: "A-001",
    student: "Emma Miller",
    parent: "Sarah Miller",
    teacher: "Emily Carter",
    gate: "Building A",
    arrival: "2:05 PM",
    ready: "-",
    pickup: "-",
    status: "PREPARING",
  },
  {
    queue: "A-004",
    student: "Liam Johnson",
    parent: "Michael Johnson",
    teacher: "Daniel Brooks",
    gate: "Building A",
    arrival: "2:11 PM",
    ready: "2:17 PM",
    pickup: "-",
    status: "READY",
  },
  {
    queue: "A-007",
    student: "Sophia Brown",
    parent: "Jennifer Brown",
    teacher: "Rachel Green",
    gate: "Building A",
    arrival: "2:14 PM",
    ready: "2:18 PM",
    pickup: "2:22 PM",
    status: "PICKED_UP",
  },
];

export default function LogsPage() {
  return (
    <main className="min-h-screen bg-gray-50 p-8">

      <div className="mb-8">
        <h1 className="text-2xl font-bold">
          Pickup Logs
        </h1>

        <p className="mt-1 text-sm text-gray-400">
          Complete record of student pickup activity
        </p>
      </div>

      <div className="rounded-xl border border-gray-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-400">
            <tr>
              <th className="px-5 py-4">Queue</th>
              <th className="px-5 py-4">Student</th>
              <th className="px-5 py-4">Parent</th>
              <th className="px-5 py-4">Teacher</th>
              <th className="px-5 py-4">Arrival</th>
              <th className="px-5 py-4">Ready</th>
              <th className="px-5 py-4">Picked Up</th>
              <th className="px-5 py-4">Status</th>
            </tr>
          </thead>

          <tbody>
            {logs.map((log) => (
              <tr
                key={log.queue}
                className="border-t border-gray-100"
              >
                <td className="px-5 py-5 font-bold">
                  {log.queue}
                </td>

                <td className="px-5 py-5 font-semibold">
                  {log.student}
                </td>

                <td className="px-5 py-5">
                  {log.parent}
                </td>

                <td className="px-5 py-5">
                  {log.teacher}
                </td>

                <td className="px-5 py-5">
                  {log.arrival}
                </td>

                <td className="px-5 py-5">
                  {log.ready}
                </td>

                <td className="px-5 py-5">
                  {log.pickup}
                </td>

                <td className="px-5 py-5">
                  <StatusBadge status={log.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

    </main>
  );
}

function StatusBadge({ status }) {
  const labels = {
    PREPARING: "Preparing",
    READY: "Ready",
    PICKED_UP: "Picked Up",
  };

  const styles = {
    PREPARING: "bg-yellow-50 text-yellow-700",
    READY: "bg-green-50 text-green-700",
    PICKED_UP: "bg-gray-100 text-gray-700",
  };

  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-semibold ${styles[status]}`}
    >
      {labels[status]}
    </span>
  );
}

function AdminSidebar({ active }) {
  return (
    <aside className="w-64 border-r border-gray-200 bg-white">
      <div className="border-b border-gray-200 px-6 py-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-black text-white">
            <School size={20} />
          </div>

          <div>
            <p className="font-bold">ATG</p>
            <p className="text-xs text-gray-400">
              Admin Console
            </p>
          </div>
        </div>
      </div>

      <nav className="space-y-1 p-4">
        <SidebarLink
          href="/admin"
          label="Dashboard"
          icon={<LayoutDashboard size={18} />}
          active={active === "dashboard"}
        />

        <SidebarLink
          href="/admin/duty"
          label="Duty Schedule"
          icon={<CalendarDays size={18} />}
          active={active === "duty"}
        />

        <SidebarLink
          href="/admin/logs"
          label="Pickup Logs"
          icon={<ClipboardList size={18} />}
          active={active === "logs"}
        />

        <SidebarLink
          href="/admin/users"
          label="User Management"
          icon={<Users size={18} />}
          active={active === "users"}
        />

        <SidebarLink
          href="/admin/queue"
          label="Queue Monitor"
          icon={<Monitor size={18} />}
          active={active === "queue"}
        />
      </nav>
    </aside>
  );
}

function SidebarLink({
  href,
  label,
  icon,
  active,
}) {
  return (
    <Link
      href={href}
      className={`flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium ${
        active
          ? "bg-black text-white"
          : "text-gray-500 hover:bg-gray-100"
      }`}
    >
      {icon}
      {label}
    </Link>
  );
}