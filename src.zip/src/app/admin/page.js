
import {pickups} from "@/data/pickups";

import {
  ClipboardList,
  Clock3,
  CircleCheck,
  UserCheck,
} from "lucide-react";



const dutyTeachers = [
  {
    name: "Emily Carter",
    classroom: "KG-1A",
    gate: "Building A",
  },
  {
    name: "Daniel Brooks",
    classroom: "KG-1B",
    gate: "Building A",
  },
  {
    name: "Rachel Green",
    classroom: "KG-2A",
    gate: "Building B",
  },
];

export default function AdminPage() {
  return (
    <main className="min-h-screen bg-gray-50 text-gray-900">

      {/* HEADER */}
      <header className="flex items-center justify-between border-b border-gray-200 bg-white px-8 py-5">
        <div>
          <h1 className="text-2xl font-bold">
            Admin Dashboard
          </h1>

          <p className="mt-1 text-sm text-gray-400">
            Student pickup operations overview
          </p>
        </div>

        <div className="text-right">
          <p className="text-sm font-semibold">
            Administrator
          </p>

          <p className="text-xs text-gray-400">
            ATG School
          </p>
        </div>
      </header>

      {/* DASHBOARD CONTENT */}
      <div className="space-y-8 p-8">

        {/* SUMMARY CARDS */}
        <section className="grid grid-cols-4 gap-5">

          <StatCard
            title="Total Pickups"
            value="10"
            subtitle="Today"
            icon={<ClipboardList size={20} />}
          />

          <StatCard
            title="Preparing"
            value="4"
            subtitle="Active requests"
            icon={<Clock3 size={20} />}
          />

          <StatCard
            title="Ready"
            value="3"
            subtitle="Waiting at gate"
            icon={<CircleCheck size={20} />}
          />

          <StatCard
            title="Picked Up"
            value="3"
            subtitle="Completed today"
            icon={<UserCheck size={20} />}
          />

        </section>

        {/* MAIN INFORMATION */}
        <section className="grid grid-cols-3 gap-6">

          {/* RECENT PICKUPS */}
          <div className="col-span-2 overflow-hidden rounded-xl border border-gray-200 bg-white">

            <div className="flex items-center justify-between border-b border-gray-200 px-6 py-5">
              <div>
                <h2 className="font-semibold">
                  Recent Pickup Activity
                </h2>

                <p className="mt-1 text-xs text-gray-400">
                  Latest pickup requests today
                </p>
              </div>

              <button
                type="button"
                className="text-sm font-semibold text-gray-500 transition hover:text-black"
              >
                View All
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">

                <thead className="bg-gray-50 text-xs uppercase text-gray-400">
                  <tr>
                    <th className="px-6 py-4">
                      Queue
                    </th>

                    <th className="px-6 py-4">
                      Student
                    </th>

                    <th className="px-6 py-4">
                      Teacher
                    </th>

                    <th className="px-6 py-4">
                      Arrival
                    </th>

                    <th className="px-6 py-4">
                      Status
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {pickups.map((pickup) => (
                    <tr
                      key={pickup.queueNumber}
                      className="border-t border-gray-100"
                    >
                      <td className="px-6 py-5 font-bold">
                        {pickup.queueNumber}
                      </td>

                      <td className="px-6 py-5">
                        <p className="font-semibold">
                          {pickup.studentName}
                        </p>

                        <p className="mt-1 text-xs text-gray-400">
                          {pickup.parentName}
                        </p>
                      </td>

                      <td className="px-6 py-5">
                        {pickup.teacher}
                      </td>

                      <td className="px-6 py-5 text-gray-500">
                        {pickup.arrivalTime}
                      </td>

                      <td className="px-6 py-5">
                        <StatusBadge
                          status={pickup.status}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>

              </table>
            </div>

          </div>

          {/* TEACHERS ON DUTY */}
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">

            <div className="border-b border-gray-200 px-6 py-5">
              <h2 className="font-semibold">
                Teachers On Duty
              </h2>

              <p className="mt-1 text-xs text-gray-400">
                Current dismissal assignments
              </p>
            </div>

            <div className="divide-y divide-gray-100">
              {dutyTeachers.map((teacher) => (
                <div
                  key={teacher.name}
                  className="px-6 py-5"
                >
                  <div className="flex items-start justify-between gap-4">

                    <div>
                      <p className="text-sm font-semibold">
                        {teacher.name}
                      </p>

                      <p className="mt-1 text-xs text-gray-400">
                        {teacher.classroom}
                      </p>
                    </div>

                    <span className="whitespace-nowrap rounded-full bg-green-50 px-3 py-1 text-[10px] font-semibold text-green-700">
                      On Duty
                    </span>

                  </div>

                  <p className="mt-3 text-xs text-gray-500">
                    {teacher.gate}
                  </p>
                </div>
              ))}
            </div>

          </div>

        </section>

        {/* BOTTOM SECTION */}
        <section className="grid grid-cols-2 gap-6">

          {/* GATE STATUS */}
          <div className="rounded-xl border border-gray-200 bg-white p-6">

            <div className="flex items-start justify-between">

              <div>
                <h2 className="font-semibold">
                  Gate Status
                </h2>

                <p className="mt-1 text-xs text-gray-400">
                  Live pickup gate overview
                </p>
              </div>

              <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                Operational
              </span>

            </div>

            <div className="mt-6 grid grid-cols-3 gap-4">

              <MiniStat
                label="Preparing"
                value="4"
              />

              <MiniStat
                label="Ready"
                value="3"
              />

              <MiniStat
                label="Completed"
                value="3"
              />

            </div>

            <a
              href="/admin/queue"
              className="mt-6 block w-full rounded-lg bg-black py-3 text-center text-sm font-semibold text-white transition hover:bg-gray-800"
            >
              Open Queue Monitor
            </a>

          </div>

          {/* SYSTEM ACTIVITY */}
          <div className="rounded-xl border border-gray-200 bg-white p-6">

            <h2 className="font-semibold">
              System Activity
            </h2>

            <p className="mt-1 text-xs text-gray-400">
              Recent operational events
            </p>

            <div className="mt-5 space-y-4">

              <Activity
                title="A-007 marked as Picked Up"
                time="2:22 PM"
              />

              <Activity
                title="A-004 marked Ready"
                time="2:17 PM"
              />

              <Activity
                title="A-010 pickup request received"
                time="2:17 PM"
              />

            </div>

          </div>

        </section>

      </div>
    </main>
  );
}


/* --------------------------------
   COMPONENTS
--------------------------------- */

function StatCard({
  title,
  value,
  subtitle,
  icon,
}) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-5">

      <div className="flex items-start justify-between">

        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-gray-400">
            {title}
          </p>

          <p className="mt-3 text-3xl font-bold">
            {value}
          </p>

          <p className="mt-1 text-xs text-gray-400">
            {subtitle}
          </p>
        </div>

        <div className="rounded-lg bg-gray-100 p-3 text-gray-500">
          {icon}
        </div>

      </div>

    </div>
  );
}


function StatusBadge({ status }) {
  const styles = {

    NEW: 
      "bg-blue-50 text-blue-700",

    PREPARING:
      "bg-yellow-50 text-yellow-700",

    READY:
      "bg-green-50 text-green-700",

    PICKED_UP:
      "bg-gray-100 text-gray-700",
  };

  const labels = {
    NEW: "New",
    PREPARING: "Preparing",
    READY: "Ready",
    PICKED_UP: "Picked Up",
  };

  return (
    <span
      className={`whitespace-nowrap rounded-full px-3 py-1 text-xs font-semibold ${
        styles[status] || "bg-gray-100 text-gray-700"
      }`}
    >
      {labels[status] || status}
    </span>
  );
}


function MiniStat({
  label,
  value,
}) {
  return (
    <div className="rounded-lg bg-gray-50 p-4">

      <p className="text-xs text-gray-400">
        {label}
      </p>

      <p className="mt-2 text-2xl font-bold">
        {value}
      </p>

    </div>
  );
}


function Activity({
  title,
  time,
}) {
  return (
    <div className="flex items-start justify-between border-b border-gray-100 pb-4 last:border-none last:pb-0">

      <p className="text-sm">
        {title}
      </p>

      <span className="ml-4 whitespace-nowrap text-xs text-gray-400">
        {time}
      </span>

    </div>
  );
}