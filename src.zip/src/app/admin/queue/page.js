"use client";

const queues = [
  {
    queue: "A-001",
    student: "Emma Miller",
    classroom: "KG-1A",
    teacher: "Emily Carter",
    status: "PREPARING",
  },
  {
    queue: "A-004",
    student: "Liam Johnson",
    classroom: "KG-1A",
    teacher: "Daniel Brooks",
    status: "READY",
  },
  {
    queue: "A-007",
    student: "Sophia Brown",
    classroom: "KG-1A",
    teacher: "Rachel Green",
    status: "PICKED_UP",
  },
];

export default function QueuePage() {
  return (
    <main className="min-h-screen bg-gray-50 p-8">

      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">
            Queue Monitor
          </h1>

          <p className="mt-1 text-sm text-gray-400">
            Live administrative view of the pickup queue
          </p>
        </div>

        <span className="rounded-full bg-green-50 px-4 py-2 text-xs font-semibold text-green-700">
          ● Live
        </span>
      </div>

      <div className="mt-8 grid grid-cols-3 gap-5">
        <QueueColumn
          title="Preparing"
          status="PREPARING"
          queues={queues}
        />

        <QueueColumn
          title="Ready"
          status="READY"
          queues={queues}
        />

        <QueueColumn
          title="Picked Up"
          status="PICKED_UP"
          queues={queues}
        />
      </div>

    </main>
  );
}

function QueueColumn({
  title,
  status,
  queues,
}) {
  const items = queues.filter(
    (queue) => queue.status === status
  );

  return (
    <section className="rounded-xl border border-gray-200 bg-white">

      <div className="border-b border-gray-200 p-5">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">
            {title}
          </h2>

          <span className="text-xl font-bold">
            {items.length}
          </span>
        </div>
      </div>

      <div className="space-y-3 p-4">
        {items.map((item) => (
          <div
            key={item.queue}
            className="rounded-lg border border-gray-200 p-4"
          >
            <p className="text-xl font-bold">
              {item.queue}
            </p>

            <p className="mt-2 text-sm font-semibold">
              {item.student}
            </p>

            <p className="mt-1 text-xs text-gray-400">
              {item.classroom}
            </p>

            <p className="mt-3 text-xs text-gray-500">
              {item.teacher}
            </p>
          </div>
        ))}
      </div>

    </section>
  );
}